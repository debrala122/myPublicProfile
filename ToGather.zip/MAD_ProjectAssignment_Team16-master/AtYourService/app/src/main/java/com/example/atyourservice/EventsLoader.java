package com.example.atyourservice;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class EventsLoader extends RecyclerView.ViewHolder {

    public EventsLoader(@NonNull View itemView) {
        super(itemView);
    }
}

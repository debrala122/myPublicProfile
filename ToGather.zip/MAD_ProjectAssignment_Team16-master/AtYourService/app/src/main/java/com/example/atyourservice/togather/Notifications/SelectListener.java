package com.example.atyourservice.togather.Notifications;

import com.example.atyourservice.models.Notification;

public interface SelectListener {
    void onItemClicked(Notification notification);
}

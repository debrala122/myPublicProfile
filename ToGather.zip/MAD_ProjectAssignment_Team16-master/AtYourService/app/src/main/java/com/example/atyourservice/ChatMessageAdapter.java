/*package com.example.atyourservice;

import android.content.Context;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.atyourservice.ChatPackage.ReceivedMessagesHolder;

import java.util.List;

public class ChatMessageAdapter extends RecyclerView.Adapter<ReceivedMessagesHolder> {
    //create class of messages to hold ,
    public ChatMessageAdapter(List<Messages>, Context context){

    }
    @NonNull
    @Override
    public ReceivedMessagesHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull ReceivedMessagesHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }
}
*/
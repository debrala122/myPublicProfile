package com.example.atyourservice.models;

import android.graphics.drawable.Drawable;

public class HomePageActivities {
    int activityImage;
    String activityName;

    public int getActivityImage() {
        return activityImage;
    }

    public void setActivityImage(int activityImage) {
        this.activityImage = activityImage;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }
}
